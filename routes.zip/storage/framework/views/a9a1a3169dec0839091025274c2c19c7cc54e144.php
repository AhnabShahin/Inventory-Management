<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid pt-4 px-4">
    <?php if(session()->has('message')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="fa fa-exclamation-circle me-2"></i> <?php echo e(session()->get('message')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    <?php if(session()->has('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="fa fa-exclamation-circle me-2"></i> <?php echo e(session()->get('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    <form action="<?php echo e(route('sell')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row g-4">
            <?php $__currentLoopData = $card_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$card_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-12 col-xl-6">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4">Item #<?php echo e($key+1); ?></h6>
                    <dl class="row mb-0">
                        <dt class="col-sm-4">Product Code</dt>
                        <dd class="col-sm-8"><?php echo e($card_item->product->product_id); ?></dd>

                        <dt class="col-sm-4">Category</dt>
                        <dd class="col-sm-8"><?php echo e($card_item->product->category->name); ?></dd>

                        <dt class="col-sm-4"> Title</dt>
                        <dd class="col-sm-8"><?php echo e($card_item->product->title); ?></dd>

                        <dt class="col-sm-4"> Brand</dt>
                        <dd class="col-sm-8"><?php echo e($card_item->product->brand); ?></dd>

                        <dt class="col-sm-4"> Color</dt>
                        <dd class="col-sm-8"><?php echo e($card_item->color); ?></dd>

                        <dt class="col-sm-4"> Size</dt>
                        <dd class="col-sm-8"><?php echo e($card_item->size); ?></dd>

                        <dt class="col-sm-4"> Quantity</dt>
                        <dd class="col-sm-8"><?php echo e($card_item->quantity); ?></dd>

                        <dt class="col-sm-4"> Unit Price</dt>
                        <dd class="col-sm-8"><?php echo e($card_item->product_attribute->unit_price); ?></dd>

                        <dt class="col-sm-4"> Unit Selling Price</dt>
                        <dd class="col-sm-8">
                            <input type="number" name="unit_selling_price[]" class="form-control form-control-sm " id="unit_selling_price" placeholder="Selling Price">
                            <?php if($errors->has('unit_selling_price.'.$key)): ?>
                            <span class="text-danger">This field is required</span>
                            <?php endif; ?>
                        </dd>
                    </dl>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-12 col-xl-6">
                <div class="bg-light rounded h-100 p-4">
                    <div class="mb-3">
                        <label for="customer_id">Select Customer Of those Orders</label>
                        <select class="form-select" id="customer_id" name="customer_id" aria-label="Floating label select example">
                            <option value=<?php echo e(Null); ?>>Select Customer</option>
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->customer_id); ?> - <?php echo e($customer->first_name); ?> - <?php echo e($customer->mobile); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('customer_id')): ?>
                        <span class="text-danger"><?php echo e($errors->first('customer_id')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-floating mb-3">
                        <textarea class="form-control" placeholder="Delivery Address " name="delivery_address" id="delivery_address" style="height: 100px;"></textarea>
                        <label for="delivery_address">Product Delivery Address</label>
                    </div>
                    <div class="form mb-3">
                        <label for="discount">Discount Amount On Total Bill</label>
                        <input class="form-control"  type="number" placeholder="0" name="discount" id="discount">
                    </div>
                    <div class="mb-3">
                        <label for="payment_type">Payment Type</label>
                        <select class="form-select" id="payment_type" name="payment_type" aria-label="Floating label select example">
                            <option value=<?php echo e(Null); ?>>Select Payment Type</option>
                            <option value="Hand Cash">Hand Cash</option>
                            <option value="Bkash">Bkash</option>
                            <option value="Nogod">Nogod</option>
                            <option value="Rocket">Rocket</option>
                            <option value="Others">Others</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Sell Now !!</button>
                </div>
            </div>
        </div>
    </form>
</div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Shahin\Desktop\Laravel\inventory-management\resources\views/check-out.blade.php ENDPATH**/ ?>