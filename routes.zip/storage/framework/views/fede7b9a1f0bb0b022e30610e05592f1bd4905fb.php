<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid pt-4 px-4 ">
    <?php if(session()->has('message')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="fa fa-exclamation-circle me-2"></i> <?php echo e(session()->get('message')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    <?php if(session()->has('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="fa fa-exclamation-circle me-2"></i> <?php echo e(session()->get('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    <div class="row g-3">
        <div class="col-sm-12 col-xl-12">
            <div class="bg-light text-center rounded p-4">
                <div class="d-flex align-items-center justify-content-between mb-4">
                    <h6 class="mb-0">All Sells Details</h6>
                </div>
                <div class="table-responsive">
                    <table class="table text-start align-middle table-bordered table-hover mb-0">
                        <thead>
                            <tr class="text-dark">
                                <th scope="col" style="white-space: nowrap">Sell ID</th>
                                <th scope="col" style="white-space: nowrap">Items On sell</th>
                                <th scope="col" style="white-space: nowrap">Selling Price</th>
                                <th scope="col" style="white-space: nowrap">Discount</th>
                                <th scope="col" style="white-space: nowrap">Payment Type</th>
                                <th scope="col" style="white-space: nowrap">Invoice Download</th>
                                <th scope="col" style="white-space: nowrap">More Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $sells; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="white-space: nowrap"><?php echo e($sell->sell_id); ?></td>
                                <td>
                                    <?php if(!$sell->orders->isEmpty()): ?>
                                    <table class="table text-center align-middle table-bordered table-hover mb-0">
                                        <thead>
                                            <tr class="text-dark">
                                                <th scope="col">Color</th>
                                                <th scope="col">Size</th>
                                                <th scope="col">Quantity</th>
                                                <th scope="col">Unit Selling Price</th>
                                                <th scope="col">Total selling Price</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $sell->orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($order->color); ?></td>
                                                <td><?php echo e($order->size); ?></td>
                                                <td><?php echo e($order->quantity); ?></td>
                                                <td><?php echo e($order->unit_selling_price); ?></td>
                                                <td><?php echo e($order->total_selling_price); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($sell->sell_price_after_discount); ?></td>
                                <td><?php echo e($sell->discount); ?></td>
                                <td><?php echo e($sell->payment_type); ?></td>
                                <td >
                                    <a class="btn btn-sm btn-primary" href="<?php echo e(route('invoiceDownload',[$sell->id])); ?>">Invoice</a>
                                </td>
                                <td >
                                    <a class="btn btn-sm btn-primary" href="<?php echo e(route('sellDetails',[$sell->id])); ?>">Details</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Shahin\Desktop\Laravel\inventory-management\resources\views/sells.blade.php ENDPATH**/ ?>