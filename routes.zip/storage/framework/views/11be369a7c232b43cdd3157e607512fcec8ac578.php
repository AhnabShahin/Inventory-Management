<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid pt-4 px-4">
    <?php if(session()->has('message')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="fa fa-exclamation-circle me-2"></i> <?php echo e(session()->get('message')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    <?php if(session()->has('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="fa fa-exclamation-circle me-2"></i> <?php echo e(session()->get('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    <div class="row g-4">
        <div class="col-sm-12 col-xl-4">
            <div class="h-100 bg-light rounded p-4">
                <div class="d-flex align-items-center justify-content-between mb-4">
                    <h6 class="mb-0">Create Category</h6>
                </div>
                <form class="d-flex mb-2" method="post" action="<?php echo e(route('saveCategory')); ?>">
                    <?php echo csrf_field(); ?>
                    <input class="form-control bg-transparent" name="name" type="text" placeholder="Enter task">
                    <button type="submit" class="btn btn-primary ms-2">Add</button>
                </form>

                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="d-flex align-items-center border-bottom py-2">
                    <!-- <input class="form-check-input m-0" type="checkbox"> -->
                    <div class="w-100 ms-3">
                        <div class="d-flex w-100 align-items-center justify-content-between">
                            <span><?php echo e($category['name']); ?></span>
                            <a href="<?php echo e(route('deleteCategory', [$category['id']])); ?>" class="btn btn-sm"><i class="fa fa-times"></i></a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
        <div class="col-sm-12 col-xl-8">
            <div class="bg-light rounded h-100 p-4">
                <h6 class="mb-4">Entry New Product</h6>
                <form action="<?php echo e(route('saveProduct')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-floating mb-3">
                        <input type="text" name="title" class="form-control" id="title" placeholder="Title">
                        <label for="title">Title</label>
                    </div>
                    <div class="form-floating mb-3">
                        <select class="form-select" id="category_id" name="category_id" aria-label="Floating label select example">
                            <option value=<?php echo e(Null); ?>>Select category</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <label for="category_id">Select Category For Product</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="text" name="brand" class="form-control" id="brand" placeholder="Brand Name">
                        <label for="brand">Brand Name</label>
                    </div>
                    <div class="form-floating mb-3">
                        <textarea class="form-control" placeholder="Product summary" name="summary" id="summary" style="height: 100px;"></textarea>
                        <label for="address">Product summary</label>
                    </div>
                    <div class="mb-3">
                        <label for="images" class="form-label">Product Images</label>
                        <input class="form-control" name="images[]" type="file" id="images" multiple>
                    </div>
                    <button type="submit" class="btn btn-primary">Add Now !!</button>
                </form>
            </div>
        </div>
        <div class="col-sm-12 col-xl-12">
            <div class="bg-light rounded h-100 p-4">
                <h6 class="mb-4">Entry Product Attributes</h6>
                <form action="<?php echo e(route('saveProductAttribute')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="product_id">Select Product For Set Attributes</label>
                        <select class="form-select " id="product_id" name="product_id">
                            <option value=<?php echo e(Null); ?>>Select product</option>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($product->id); ?>"><?php echo e($product->product_id); ?> <span> -- <?php echo e($product->title); ?> </span></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('product_id')): ?>
                        <span class="text-danger"><?php echo e($errors->first('product_id')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <label for="color">Product Color</label>
                        <input type="text" name="color" class="form-control" id="color" placeholder="Exm : Green">
                        <?php if($errors->has('color')): ?>
                        <span class="text-danger"><?php echo e($errors->first('color')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <label for="size">Product Size</label>
                        <input type="text" name="size" class="form-control" id="size" placeholder="Exm : XL">
                        <?php if($errors->has('size')): ?>
                        <span class="text-danger"><?php echo e($errors->first('size')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <label for="quantity">Quantity</label>
                        <input type="number" name="quantity" class="form-control" id="quantity" min="1" placeholder="Quantity">
                        <?php if($errors->has('quantity')): ?>
                        <span class="text-danger"><?php echo e($errors->first('quantity')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <label for="unit_price">Single Unit Price</label>
                        <input type="number" step="any" name="unit_price" class="form-control" id="quantity" min="0" placeholder="Price">
                        <?php if($errors->has('unit_price')): ?>
                        <span class="text-danger"><?php echo e($errors->first('unit_price')); ?></span>
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-primary">Add Now !!</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Shahin\Desktop\Laravel\inventory-management\resources\views/product-form.blade.php ENDPATH**/ ?>