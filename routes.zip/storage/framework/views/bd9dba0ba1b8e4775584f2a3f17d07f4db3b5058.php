<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid pt-4 px-4">

    <?php if(session()->has('message')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="fa fa-exclamation-circle me-2"></i> <?php echo e(session()->get('message')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    <?php if(session()->has('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="fa fa-exclamation-circle me-2"></i> <?php echo e(session()->get('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    <div class="row g-4">
        <div class="col-sm-12 col-xl-6">
            <div class="bg-light rounded h-100 p-4">
                <h6 class="mb-4">Update Product Details</h6>
                <form action="<?php echo e(route('updateProductAttribute',[$productAttribute->id])); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="color">Product Color</label>
                        <input type="text" name="color" value="<?php echo e($productAttribute->color); ?>" class="form-control" id="color" placeholder="Exm : Green">
                        <?php if($errors->has('color')): ?>
                        <span class="text-danger"><?php echo e($errors->first('color')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <label for="size">Product Size</label>
                        <input type="text" name="size" value="<?php echo e($productAttribute->size); ?>" class="form-control" id="size" placeholder="Exm : XL">
                        <?php if($errors->has('size')): ?>
                        <span class="text-danger"><?php echo e($errors->first('size')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <label for="quantity">Quantity</label>
                        <input type="number" name="quantity" value="<?php echo e($productAttribute->quantity); ?>" class="form-control" id="quantity" min="1" placeholder="Quantity">
                        <?php if($errors->has('quantity')): ?>
                        <span class="text-danger"><?php echo e($errors->first('quantity')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <label for="unit_price">Single Unit Price</label>
                        <input type="number" step="any" value="<?php echo e($productAttribute->unit_price); ?>" name="unit_price" class="form-control" id="quantity" min="0" placeholder="Price">
                        <?php if($errors->has('unit_price')): ?>
                        <span class="text-danger"><?php echo e($errors->first('unit_price')); ?></span>
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-primary">Update Now !!</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Shahin\Desktop\Laravel\inventory-management\resources\views/update-product-attribute.blade.php ENDPATH**/ ?>